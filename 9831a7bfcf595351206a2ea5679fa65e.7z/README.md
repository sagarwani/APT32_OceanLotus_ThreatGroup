MalShare Toolkit
==============


Set of tools for interacting with MalShare API
Tools:
malshare_digest 
--------------
*Generate a CSV file of daily MD5 list*

	usage: malshare_digest [-h] -o OUTFILE
	malshare_digest: error: argument -o/--outfile is required


wget_malshare
--------------
*Download sample*

	usage: wget_malshare [-h] [-k APIKEY] -d DOWNLOAD [-xVXCAGE]
	wget_malshare: error: argument -d/--download is required

wget_malshare_daily
--------------
*Download all samples from the day prior*

        usage: wget_malshare_daily [-h] [-k APIKEY] -d DOWNLOAD [-x VXCAGE]
        wget_malshare_daily: error: argument -d/--download is required


		 
Don't forget to set your API Key for wget_malshare && wget_malshare_daily
